
#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <unordered_set>
#include <random>
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

class HashFuncGen {
public:
    explicit HashFuncGen(uint32_t seed = 0xB0F57EE3u) : seed_(seed) {}

    uint32_t operator()(const std::string& s) const {
        return murmur3_32(reinterpret_cast<const uint8_t*>(s.data()), (int)s.size(), seed_);
    }

private:
    uint32_t seed_;
    static inline uint32_t rotl32(uint32_t x, int8_t r) {
        return (x << r) | (x >> (32 - r));
    }
    static inline uint32_t fmix32(uint32_t h) {
        h ^= h >> 16;
        h *= 0x85ebca6bu;
        h ^= h >> 13;
        h *= 0xc2b2ae35u;
        h ^= h >> 16;
        return h;
    }

    static uint32_t murmur3_32(const uint8_t* data, int len, uint32_t seed) {
        const int nblocks = len / 4;
        uint32_t h1 = seed;
        const uint32_t c1 = 0xcc9e2d51u;
        const uint32_t c2 = 0x1b873593u;
        const uint32_t* blocks = reinterpret_cast<const uint32_t*>(data);
        for (int i = 0; i < nblocks; ++i) {
            uint32_t k1 = blocks[i];
            k1 *= c1;
            k1 = rotl32(k1, 15);
            k1 *= c2;

            h1 ^= k1;
            h1 = rotl32(h1, 13);
            h1 = h1 * 5u + 0xe6546b64u;
        }
        const uint8_t* tail = data + nblocks * 4;
        uint32_t k1 = 0;
        switch (len & 3) {
            case 3: k1 ^= uint32_t(tail[2]) << 16; [[fallthrough]];
            case 2: k1 ^= uint32_t(tail[1]) << 8;  [[fallthrough]];
            case 1:
                k1 ^= uint32_t(tail[0]);
                k1 *= c1;
                k1 = rotl32(k1, 15);
                k1 *= c2;
                h1 ^= k1;
        }
        h1 ^= uint32_t(len);
        h1 = fmix32(h1);
        return h1;
    }
};

class RandomStreamGen {
public:
    struct Params {
        size_t stream_len = 50'000;
        double p_repeat   = 0.30;
        uint32_t seed     = 42;
        size_t max_len    = 30;
        size_t warm_pool  = 10'000;
    };

    RandomStreamGen() : RandomStreamGen(Params{}) {}

    explicit RandomStreamGen(Params p)
        : p_(p), rng_(p.seed), uni01_(0.0, 1.0)
    {
        if (p_.max_len == 0 || p_.max_len > 30) {
            throw std::invalid_argument("max_len must be in [1,30]");
        }
        alphabet_ = build_alphabet();
    }

    std::vector<std::string> generate_stream() {
        std::vector<std::string> stream;
        stream.reserve(p_.stream_len);
        pool_.clear();
        pool_.reserve(std::min(p_.stream_len, p_.warm_pool));

        for (size_t i = 0; i < p_.stream_len; ++i) {
            const bool can_repeat = !pool_.empty();
            const bool repeat = can_repeat && (uni01_(rng_) < p_.p_repeat);

            if (repeat) {
                std::uniform_int_distribution<size_t> pick(0, pool_.size() - 1);
                stream.push_back(pool_[pick(rng_)]);
            } else {
                std::string s = random_string();
                stream.push_back(s);
                if (pool_.size() < p_.warm_pool) pool_.push_back(s);
            }
        }
        return stream;
    }

    static std::vector<size_t> split_points(size_t n, double step_fraction) {
        if (!(step_fraction > 0.0 && step_fraction <= 1.0)) {
            throw std::invalid_argument("step_fraction must be in (0,1]");
        }
        const size_t step = std::max<size_t>(1, size_t(std::llround(double(n) * step_fraction)));
        std::vector<size_t> points;
        for (size_t i = step; i <= n; i += step) points.push_back(i);
        if (points.empty() || points.back() != n) points.push_back(n);
        return points;
    }

private:
    Params p_;
    std::mt19937 rng_;
    std::uniform_real_distribution<double> uni01_;
    std::string alphabet_;
    std::vector<std::string> pool_;

    static std::string build_alphabet() {
        std::string a;
        for (char c = 'a'; c <= 'z'; ++c) a.push_back(c);
        for (char c = 'A'; c <= 'Z'; ++c) a.push_back(c);
        for (char c = '0'; c <= '9'; ++c) a.push_back(c);
        a.push_back('-');
        return a;
    }

    std::string random_string() {
        std::uniform_int_distribution<size_t> len_dist(1, p_.max_len);
        const size_t len = len_dist(rng_);
        std::uniform_int_distribution<size_t> ch_dist(0, alphabet_.size() - 1);

        std::string s(len, 'a');
        for (size_t i = 0; i < len; ++i) s[i] = alphabet_[ch_dist(rng_)];
        return s;
    }
};

class ExactDistinctCounter {
public:
    void reset() { set_.clear(); }
    void add(const std::string& s) { set_.insert(s); }
    size_t value() const { return set_.size(); }
private:
    std::unordered_set<std::string> set_;
};

class HyperLogLog {
public:
    explicit HyperLogLog(uint8_t B)
        : B_(B), m_(size_t(1) << B_), regs_(m_, 0)
    {
        if (B_ < 4 || B_ > 20) throw std::invalid_argument("B in [4,20]");
    }

    void reset() { std::fill(regs_.begin(), regs_.end(), 0); }
    uint8_t B() const { return B_; }
    size_t  m() const { return m_; }

    void add_hash(uint32_t x) {
        const uint32_t idx = x >> (32 - B_);
        const uint32_t w   = x << B_;
        const uint8_t  rho = (w == 0u) ? uint8_t((32 - B_) + 1) : uint8_t(leading_zeros_32(w) + 1);
        if (rho > regs_[idx]) regs_[idx] = rho;
    }

    template<class HashFn>
    void add(const std::string& s, const HashFn& hf) { add_hash(hf(s)); }

    double estimate() const {
        const double m = double(m_);
        const double alpha = alpha_m();

        double z = 0.0;
        size_t V = 0;
        for (uint8_t r : regs_) {
            z += std::ldexp(1.0, -int(r)); // 2^{-r}
            if (r == 0) ++V;
        }
        double E = alpha * m * m / z;
        if (E <= 2.5 * m && V > 0) {
            E = m * std::log(m / double(V));
        }
        const double two32 = 4294967296.0;
        if (E > (two32 / 30.0)) {
            E = -two32 * std::log(1.0 - E / two32);
        }
        return E;
    }

private:
    uint8_t B_;
    size_t m_;
    std::vector<uint8_t> regs_;

    static inline uint8_t leading_zeros_32(uint32_t x) {
#if defined(__GNUG__) || defined(__clang__)
        if (x == 0) return 32;
        return uint8_t(__builtin_clz(x));
#else
        uint8_t n = 0;
        while ((x & 0x80000000u) == 0u && n < 32) { x <<= 1; ++n; }
        return n;
#endif
    }

    double alpha_m() const {
        if (m_ == 16) return 0.673;
        if (m_ == 32) return 0.697;
        if (m_ == 64) return 0.709;
        const double m = double(m_);
        return 0.7213 / (1.0 + 1.079 / m);
    }
};

class PackedHyperLogLog {
public:
    explicit PackedHyperLogLog(uint8_t B)
        : B_(B), m_(size_t(1) << B_)
    {
        if (B_ < 4 || B_ > 20) throw std::invalid_argument("B must be in [4,20]");
        // each register = 6 bits, store in 64-bit blocks
        const size_t total_bits = 6 * m_;
        blocks_.assign((total_bits + 63) / 64, 0ull);
    }
    void reset() { std::fill(blocks_.begin(), blocks_.end(), 0ull); }
    uint8_t B() const { return B_; }
    size_t  m() const { return m_; }

    void add_hash(uint32_t x) {
        const uint32_t idx = x >> (32 - B_);
        const uint32_t w   = x << B_;
        const uint8_t  rho = (w == 0u) ? uint8_t((32 - B_) + 1) : uint8_t(leading_zeros_32(w) + 1);
        if (rho > get(idx)) set(idx, rho);
    }

    template<class HashFn>
    void add(const std::string& s, const HashFn& hf) { add_hash(hf(s)); }
    double estimate() const {
        const double m = double(m_);
        const double alpha = alpha_m();

        double z = 0.0;
        size_t V = 0;
        for (size_t i = 0; i < m_; ++i) {
            const uint8_t r = get(i);
            z += std::ldexp(1.0, -int(r));
            if (r == 0) ++V;
        }
        double E = alpha * m * m / z;

        if (E <= 2.5 * m && V > 0) {
            E = m * std::log(m / double(V));
        }
        const double two32 = 4294967296.0;
        if (E > (two32 / 30.0)) {
            E = -two32 * std::log(1.0 - E / two32);
        }
        return E;
    }

    size_t bytes_used() const { return blocks_.size() * sizeof(uint64_t); }

private:
    uint8_t B_;
    size_t m_;
    std::vector<uint64_t> blocks_;

    static inline uint8_t leading_zeros_32(uint32_t x) {
#if defined(__GNUG__) || defined(__clang__)
        if (x == 0) return 32;
        return uint8_t(__builtin_clz(x));
#else
        uint8_t n = 0;
        while ((x & 0x80000000u) == 0u && n < 32) { x <<= 1; ++n; }
        return n;
#endif
    }

    uint8_t get(size_t i) const {
        const size_t bit = 6 * i;
        const size_t b = bit / 64;
        const size_t off = bit % 64;

        uint64_t v = blocks_[b] >> off;
        if (off > 58) { // spans two blocks
            v |= (blocks_[b + 1] << (64 - off));
        }
        return uint8_t(v & 0x3Fu);
    }

    void set(size_t i, uint8_t val) {
        val &= 0x3Fu;
        const size_t bit = 6 * i;
        const size_t b = bit / 64;
        const size_t off = bit % 64;
        blocks_[b] &= ~(uint64_t(0x3Fu) << off);
        blocks_[b] |= (uint64_t(val) << off);

        if (off > 58) { // spans
            const size_t hi = off - 58; // number of bits in next block
            blocks_[b + 1] &= ~((uint64_t(1) << hi) - 1);
            blocks_[b + 1] |= (uint64_t(val) >> (64 - off));
        }
    }

    double alpha_m() const {
        if (m_ == 16) return 0.673;
        if (m_ == 32) return 0.697;
        if (m_ == 64) return 0.709;
        const double m = double(m_);
        return 0.7213 / (1.0 + 1.079 / m);
    }
};
