
import argparse
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--infile", required=True)
    ap.add_argument("--out1", required=True)
    ap.add_argument("--out2", required=True)
    ap.add_argument("--variant", default="standard")  # "standard" or "packed"
    ap.add_argument("--stream", type=int, default=0)
    args = ap.parse_args()

    df = pd.read_csv(args.infile)
    # Keep only needed variants
    df = df[df["variant"].isin([args.variant, f"{args.variant}_mean", f"{args.variant}_sd"])].copy()

    # Coerce numeric columns (CSV contains a repeated header as a separator)
    for c in ["stream_id","step_id","processed","exact","estimate"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["processed","estimate"])


    # Graph 1: single stream
    d1 = df[df["variant"] == args.variant]
    d1 = d1[d1["stream_id"] == args.stream].sort_values("processed")
    plt.figure()
    plt.plot(d1["processed"], d1["exact"], label=r"$F_0^t$")
    plt.plot(d1["processed"], d1["estimate"], label=r"$N_t$")
    plt.xlabel("Обработано элементов, t")
    plt.ylabel("Количество уникальных элементов")
    plt.legend()
    plt.tight_layout()
    plt.savefig(args.out1)
    plt.close()

    # Graph 2: mean and +- sd band
    mean = df[df["variant"] == f"{args.variant}_mean"].sort_values("processed")
    sd = df[df["variant"] == f"{args.variant}_sd"].sort_values("processed")
    plt.figure()
    x = mean["processed"].to_numpy(dtype=float)
    plt.plot(x, mean["exact"].to_numpy(dtype=float), label=r"$\mathbb{E}[F_0^t]$")
    plt.plot(x, mean["estimate"].to_numpy(dtype=float), label=r"$\mathbb{E}[N_t]$")
    y = mean["estimate"].to_numpy()
    s = sd["estimate"].to_numpy()
    x = mean["processed"].to_numpy(dtype=float)
    plt.fill_between(x, y - s, y + s, alpha=0.2, label=r"$\mathbb{E}[N_t]\pm \sigma_{N_t}$")
    plt.xlabel("Обработано элементов, t")
    plt.ylabel("Количество уникальных элементов")
    plt.legend()
    plt.tight_layout()
    plt.savefig(args.out2)
    plt.close()

if __name__ == "__main__":
    main()
