
#include "hll.hpp"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <numeric>

struct Args {
    size_t streams = 20;
    size_t n = 50'000;
    double step = 0.05;
    uint8_t B = 14;
    double repeat = 0.30;
    uint32_t seed = 42;
    std::string out = "results.csv";
    bool packed = false;
};

static Args parse_args(int argc, char** argv) {
    Args a;
    for (int i = 1; i < argc; ++i) {
        std::string k = argv[i];
        auto need = [&](const char* name)->std::string{
            if (i + 1 >= argc) throw std::runtime_error(std::string("Missing value for ") + name);
            return argv[++i];
        };
        if (k == "--streams") a.streams = std::stoull(need("--streams"));
        else if (k == "--n") a.n = std::stoull(need("--n"));
        else if (k == "--step") a.step = std::stod(need("--step"));
        else if (k == "--B") a.B = (uint8_t)std::stoul(need("--B"));
        else if (k == "--repeat") a.repeat = std::stod(need("--repeat"));
        else if (k == "--seed") a.seed = (uint32_t)std::stoul(need("--seed"));
        else if (k == "--out") a.out = need("--out");
        else if (k == "--packed") a.packed = true;
        else throw std::runtime_error("Unknown argument: " + k);
    }
    return a;
}

template <class Sketch>
static void run(const Args& a) {
    RandomStreamGen::Params p;
    p.stream_len = a.n;
    p.p_repeat = a.repeat;
    p.seed = a.seed;
    p.max_len = 30;
    p.warm_pool = std::max<size_t>(1000, std::min<size_t>(a.n, 20000));

    RandomStreamGen gen(p);
    HashFuncGen hf(a.seed ^ 0x9E3779B9u);

    auto points = RandomStreamGen::split_points(a.n, a.step);

    std::ofstream out(a.out);
    if (!out) throw std::runtime_error("Cannot open output file: " + a.out);

    out << "variant,stream_id,step_id,processed,exact,estimate\n";
    out << std::fixed << std::setprecision(6);
    const size_t T = points.size();
    std::vector<double> sum_est(T, 0.0), sumsq_est(T, 0.0);
    std::vector<double> sum_exact(T, 0.0);

    for (size_t s = 0; s < a.streams; ++s) {
        p.seed = a.seed + uint32_t(7919u * (s + 1));
        gen = RandomStreamGen(p);

        auto stream = gen.generate_stream();
        ExactDistinctCounter exact;
        Sketch hll(a.B);

        size_t prev = 0;
        for (size_t t = 0; t < T; ++t) {
            size_t upto = points[t];
            for (size_t i = prev; i < upto; ++i) {
                exact.add(stream[i]);
                hll.add(stream[i], hf);
            }
            prev = upto;

            const size_t F0 = exact.value();
            const double Nt = hll.estimate();

            out << (a.packed ? "packed" : "standard") << ','
                << s << ',' << t << ',' << upto << ','
                << F0 << ',' << Nt << '\n';

            sum_est[t] += Nt;
            sumsq_est[t] += Nt * Nt;
            sum_exact[t] += double(F0);
        }
    }

    out << "variant,stream_id,step_id,processed,exact,estimate\n";
    for (size_t t = 0; t < T; ++t) {
        const double mean_est = sum_est[t] / double(a.streams);
        const double mean_exact = sum_exact[t] / double(a.streams);
        const double var = (sumsq_est[t] / double(a.streams)) - mean_est * mean_est;
        const double sd = var > 0.0 ? std::sqrt(var) : 0.0;

        out << (a.packed ? "packed_mean" : "standard_mean") << ','
            << -1 << ',' << t << ',' << points[t] << ','
            << mean_exact << ',' << mean_est << '\n';
        out << (a.packed ? "packed_sd" : "standard_sd") << ','
            << -2 << ',' << t << ',' << points[t] << ','
            << 0 << ',' << sd << '\n';
    }
    std::cerr << "Wrote: " << a.out << "\n";
}

int main(int argc, char** argv) {
    try {
        Args a = parse_args(argc, argv);
        if (a.packed) run<PackedHyperLogLog>(a);
        else run<HyperLogLog>(a);
    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << "\n";
        std::cerr << "Usage: ./hll_experiment [--streams N] [--n N] [--step f] [--B B] [--repeat p] [--seed s] [--out file] [--packed]\n";
        return 1;
    }
    return 0;
}
